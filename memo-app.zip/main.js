import { Storage } from './storage/storage.js';
import { registerEditorFormats } from './editor/editor.js';
import { TagAddon } from './addons/tag.js';

// 디바운싱 유틸리티 함수 (코드 개선)
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

class App {
    constructor() {
        this.storage = new Storage();
        this.notes = [];
        this.paletteContext = null; // 'cell', 'background', 'color'
        this.folders = [];
        this.activeNoteId = null;
        this.activeFolderId = 'all';
        this.quill = null;
        this.tagAddon = null;
        this.lastClickedIndex = null; // 우클릭한 위치 저장을 위한 변수
        this.highlightedTarget = null; // 현재 하이라이트된 요소 추적
        this.hasUnsavedChanges = false; // 저장되지 않은 변경사항 여부
        this.saveStatusTimeout = null; // 저장 상태 메시지 타이머

        // 노트 링크 제안 상태
        this.linkSuggestionState = {
            active: false,
            startIndex: null, // '[[' 시작 위치
            activeIndex: 0 // 리스트 선택 인덱스
        };

        // 리사이즈 상태 관리 변수
        this.resizeState = {
            isResizing: false,
            type: null, // 'col', 'row', 'table'
            target: null,
            startX: 0,
            startY: 0,
            startWidth: 0,
            startHeight: 0
        };

        this.ui = {
            folderList: document.getElementById('folder-list'),
            noteList: document.getElementById('notes-list'),
            slider: document.getElementById('image-size-slider'),
            tooltip: document.getElementById('image-resize-tooltip'),
            percent: document.getElementById('size-percentage'),
            titleInput: document.getElementById('note-title-input'),
            btnThemeToggle: document.getElementById('btn-theme-toggle'),
            btnHelp: document.getElementById('btn-help'),
            btnDailyNote: document.getElementById('btn-daily-note'),
            btnAddNote: document.getElementById('btn-add-note'),
            btnNewFolder: document.getElementById('btn-new-folder'),
            btnDeleteNote: document.getElementById('btn-delete-note'),
            searchInput: document.getElementById('search-input'),
            btnExportPdf: document.getElementById('btn-export-pdf'),
            btnRestoreNote: document.getElementById('btn-restore-note'),
            saveStatus: document.getElementById('save-status'),
            colorPicker: document.getElementById('color-picker'),
            colorPalette: document.getElementById('color-palette'),
            trashFolder: document.getElementById('trash-folder'),
            backlinksArea: document.getElementById('backlinks-area'),
            backlinksList: document.getElementById('backlinks-list'),
            helpModal: document.getElementById('help-modal'),
            btnCloseModal: document.querySelector('.btn-close-modal')
        };

        // 디바운싱된 자동 저장 함수 생성
        this.debouncedAutoSave = debounce(() => this.autoSave(), 1000);

        // 팔레트 색상 정의
        this.paletteColors = {
            background: [
                { color: '#ffffff', title: '기본(흰색)' },
                { color: '#f5f5f7', title: '연한 회색' },
                { color: '#ffebee', title: '연한 빨강' },
                { color: '#fff3e0', title: '연한 주황' },
                { color: '#fffde7', title: '연한 노랑' },
                { color: '#e8f5e9', title: '연한 초록' },
                { color: '#e3f2fd', title: '연한 파랑' },
                { color: '#f3e5f5', title: '연한 보라' }
            ],
            text: [
                { color: '#000000', title: '기본(검정)' },
                { color: '#8E8E93', title: '회색' },
                { color: '#FF3B30', title: '빨강' },
                { color: '#FF9500', title: '주황' },
                { color: '#FFCC00', title: '노랑' },
                { color: '#34C759', title: '초록' },
                { color: '#007AFF', title: '파랑' },
                { color: '#AF52DE', title: '보라' }
            ]
        };
    }

    async init() {
        await this.storage.init();
        this.initTheme();
        this.notes = await this.storage.getItems('notes');
        this.folders = await this.storage.getItems('folders');

        this.injectScrollbarStyles();
        this.createNoteContextMenu();
        this.createNoteLinkSuggestionBox(); // 링크 제안 박스 생성
        registerEditorFormats();

        const icons = Quill.import('ui/icons');
        icons['highlight'] = icons['background'];

        this.quill = new Quill('#editor', {
            theme: 'snow',
            placeholder: '메모를 입력하세요...',
            modules: {
                // 표 모듈 활성화
                table: true,
                toolbar: {
                    container: [
                        [{ 'header': [1, 2, false] }],
                        ['bold', 'italic', 'underline', 'color', 'highlight', 'link'],
                        [{ 'list': 'ordered'}, { 'list': 'bullet'}, { 'list': 'check' }],
                        ['image', 'table'], // 표 버튼 포함
                        ['clean']
                    ],
                    handlers: {
                        // 표 버튼 클릭 시 커스텀 동작
                        'table': () => this.insertTable(),
                        'image': () => this.insertImage(),
                        'color': () => {
                            this.paletteContext = 'color';
                            this.updatePaletteUI('text');
                            const btn = this.quill.getModule('toolbar').container.querySelector('.ql-color');
                            if (btn) {
                                const rect = btn.getBoundingClientRect();
                                this.ui.colorPalette.style.display = 'grid';
                                this.ui.colorPalette.style.left = `${rect.left}px`;
                                this.ui.colorPalette.style.top = `${rect.bottom + 5}px`;
                            }
                        },
                        'highlight': () => {
                            this.paletteContext = 'background';
                            this.updatePaletteUI('background');
                            const btn = this.quill.getModule('toolbar').container.querySelector('.ql-highlight');
                            if (btn) {
                                const rect = btn.getBoundingClientRect();
                                this.ui.colorPalette.style.display = 'grid';
                                this.ui.colorPalette.style.left = `${rect.left}px`;
                                this.ui.colorPalette.style.top = `${rect.bottom + 5}px`;
                            }
                        }
                    }
                },
                keyboard: {
                    bindings: {
                        // 스페이스바 입력 시 URL 자동 링크
                        'autoLink': {
                            key: ' ',
                            collapsed: true,
                            handler: (range, context) => {
                                const match = context.prefix.match(/(\S+)$/);
                                if (match) {
                                    const url = match[0];
                                    // URL 패턴 검사 (http, https, www로 시작)
                                    if (/^(https?:\/\/|www\.)[\w-\.]+\.[\w-\.]+[\S]*$/i.test(url)) {
                                        const index = range.index - url.length;
                                        const fullUrl = /^https?:\/\//i.test(url) ? url : 'http://' + url;
                                        this.quill.formatText(index, url.length, 'link', fullUrl, 'user');
                                        // 스페이스 삽입 후 링크 스타일 해제
                                        this.quill.insertText(range.index, ' ', 'user');
                                        this.quill.setSelection(range.index + 1, 0);
                                        this.quill.format('link', false);
                                        return false;
                                    }
                                }
                                return true;
                            }
                        }
                    }
                }
            }
        });

        this.tagAddon = new TagAddon(this);
        this.tagAddon.init();
        this.bindEvents();
        this.setupShortcuts();
        this.renderFolders();
        this.tagAddon.renderSidebarTags();
        this.renderNotes();
        
        if (this.notes.length > 0) this.loadNote(this.notes[0].id);
        else this.createNote();
    }

    // --- 테마 초기화 및 토글 ---
    initTheme() {
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        
        if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
            document.body.classList.add('dark-mode');
            this.ui.btnThemeToggle.textContent = '☀️';
        } else {
            this.ui.btnThemeToggle.textContent = '🌙';
        }

        this.ui.btnThemeToggle.onclick = () => {
            document.body.classList.toggle('dark-mode');
            const isDark = document.body.classList.contains('dark-mode');
            this.ui.btnThemeToggle.textContent = isDark ? '☀️' : '🌙';
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
        };
    }

    // --- 스크롤바 스타일 주입 ---
    injectScrollbarStyles() {
        const style = document.createElement('style');
        style.textContent = `
            #editor-container {
                flex: 1;
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }
            .ql-toolbar {
                flex-shrink: 0;
            }
            #editor {
                flex: 1;
                overflow: hidden;
                display: flex;
                flex-direction: column;
            }
            .ql-editor {
                flex: 1;
                overflow-y: auto;
                height: 100%;
            }
            .ql-editor::-webkit-scrollbar { width: 10px; }
            .ql-editor::-webkit-scrollbar-thumb { background: #ccc; border-radius: 5px; }
            .ql-editor::-webkit-scrollbar-track { background: #f0f0f0; }

            /* Context Menu Styles */
            .context-menu {
                position: absolute;
                background: var(--bg-context-menu);
                border: 1px solid var(--color-border);
                box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
                z-index: 2000;
                min-width: 160px;
                padding: 5px 0;
                border-radius: 4px;
                font-family: sans-serif;
            }
            .context-menu-item {
                padding: 8px 15px;
                cursor: pointer;
                font-size: 13px;
                color: var(--text-primary);
                display: block;
            }
            .context-menu-item:hover {
                background-color: var(--bg-context-hover);
            }
            .context-menu-separator {
                height: 1px;
                background-color: #eee;
                margin: 4px 0;
            }
            .context-menu-header {
                padding: 4px 12px;
                font-size: 11px;
                color: #999;
                font-weight: 600;
                pointer-events: none;
            }
        `;
        document.head.appendChild(style);
    }

    // --- 표 삽입 로직 (새로 추가) ---
    insertTable() {
        const rows = prompt("행(줄) 개수를 입력하세요 (예: 3)", "3");
        const cols = prompt("열(칸) 개수를 입력하세요 (예: 3)", "3");
        
        if (!rows || !cols || isNaN(rows) || isNaN(cols)) return;

        const tableModule = this.quill.getModule('table');
        // Quill 1.3.7의 기본 table 모듈을 사용하여 표 삽입
        tableModule.insertTable(parseInt(rows), parseInt(cols));
    }

    // --- 이미지 삽입 및 업로드 로직 (새로 추가) ---
    insertImage() {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
        input.click();

        input.onchange = () => {
            if (input.files && input.files[0]) {
                this.handleImageUpload(input.files[0]);
            }
        };
    }

    async handleImageUpload(file) {
        if (!this.activeNoteId) return;
        
        // Storage 클래스에 saveNoteImage 메서드가 구현되어 있어야 함 (파일 시스템 저장)
        if (this.storage.saveNoteImage) {
            try {
                const imageUrl = await this.storage.saveNoteImage(this.activeNoteId, file);
                const range = this.quill.getSelection(true) || { index: this.quill.getLength() };
                this.quill.insertEmbed(range.index, 'image', imageUrl);
            } catch (e) {
                console.error('이미지 업로드 실패:', e);
                alert('이미지 저장 중 오류가 발생했습니다.');
            }
        } else {
            alert('스토리지 모듈에 이미지 저장 기능이 구현되지 않았습니다.');
        }
    }

    bindEvents() {
        // text-change 이벤트에 디바운싱 적용 (1초 대기)
        this.quill.on('text-change', () => {
            this.hasUnsavedChanges = true;
            this.handleNoteLinkInput(); // 링크 제안 입력 감지
            this.ui.saveStatus.textContent = '저장 중...';
            this.debouncedAutoSave();
        });
        this.quill.root.addEventListener('click', (e) => {
            if (e.target.tagName === 'IMG') {
                this.selectImage(e.target);
            } else if (e.target.matches('h1, h2, h3')) {
                // 헤딩의 왼쪽 여백(화살표 영역) 클릭 감지
                const rect = e.target.getBoundingClientRect();
                // 텍스트 시작점보다 왼쪽을 클릭했는지 확인 (화살표 위치)
                if (e.clientX < rect.left) {
                    const blot = Quill.find(e.target);
                    if (blot) this.toggleSection(this.quill.getIndex(blot));
                    return; // 토글 시 다른 동작 방지
                }
            } else {
                this.deselectImage();
                const link = e.target.closest('a');
                if (link && link.getAttribute('href')) {
                    const href = link.getAttribute('href');
                    // 내부 노트 링크 처리 (http://local-note/ID)
                    if (href.startsWith('http://local-note/')) {
                        e.preventDefault(); // 브라우저의 기본 동작(페이지 이동)을 막습니다.
                        this.loadNote(href.split('http://local-note/')[1]);
                    } else if (e.ctrlKey || e.metaKey) {
                        window.open(link.href, '_blank');
                    }
                }
            }
        });
        // 에디터에 이미지 드래그 앤 드롭 시 파일 저장 처리
        this.quill.root.addEventListener('drop', (e) => {
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                const file = e.dataTransfer.files[0];
                if (file.type.startsWith('image/')) {
                    e.preventDefault();
                    this.handleImageUpload(file);
                }
            }
        });
        this.ui.slider.addEventListener('input', (e) => {
            if (this.selectedImage) this.selectedImage.style.width = e.target.value + '%';
            this.ui.percent.textContent = e.target.value + '%';
        });
        this.ui.slider.addEventListener('change', () => { this.autoSave(); this.updateTooltipPos(); });
        this.ui.btnAddNote.onclick = () => this.createNote();
        this.ui.btnDailyNote.onclick = () => this.openDailyNote();
        this.ui.btnHelp.onclick = () => this.ui.helpModal.style.display = 'flex';
        this.ui.btnNewFolder.onclick = () => this.createFolder();
        this.ui.btnDeleteNote.onclick = () => this.deleteNote();
        this.ui.searchInput.oninput = (e) => this.renderNotes(e.target.value);
        this.ui.btnRestoreNote.onclick = () => this.restoreNote();
        // 검색 필터 변경 시 재검색
        document.querySelectorAll('input[name="search-filter"]').forEach(radio => {
            radio.addEventListener('change', () => this.renderNotes(this.ui.searchInput.value));
        });
        this.ui.btnExportPdf.onclick = () => this.exportToPDF();

        // 도움말 모달 닫기 이벤트
        this.ui.btnCloseModal.onclick = () => this.ui.helpModal.style.display = 'none';
        this.ui.helpModal.onclick = (e) => {
            if (e.target === this.ui.helpModal) this.ui.helpModal.style.display = 'none';
        };

        // --- 표 컨텍스트 메뉴 로직 ---
        const contextMenu = document.getElementById('table-context-menu');
        
        // 에디터 내 우클릭 시
        this.quill.root.addEventListener('contextmenu', (e) => {
            const tableCell = e.target.closest('td, th');
            // 표 내부(td, th)를 클릭한 경우에만 메뉴 표시
            if (tableCell) {
                e.preventDefault();
                
                // 클릭한 셀 위치로 에디터 커서 이동 (그래야 해당 위치에 행/열이 추가됨)
                const blot = Quill.find(tableCell);
                if (blot) {
                    const index = this.quill.getIndex(blot);
                    this.quill.setSelection(index, 0);
                    this.lastClickedIndex = index; // 클릭 위치 저장
                }

                // 메뉴 위치 설정 및 표시
                contextMenu.style.display = 'block';
                contextMenu.style.left = `${e.pageX}px`;
                contextMenu.style.top = `${e.pageY}px`;
            }
        });

        // 메뉴 항목 클릭 시 동작
        contextMenu.addEventListener('click', (e) => {
            const action = e.target.dataset.action;
            const tableModule = this.quill.getModule('table');

            if (action === 'changeCellColor') {
                // 팔레트 표시
                this.paletteContext = 'cell';
                this.updatePaletteUI('background');
                this.ui.colorPalette.style.display = 'grid';
                this.ui.colorPalette.style.left = contextMenu.style.left;
                this.ui.colorPalette.style.top = contextMenu.style.top;
                contextMenu.style.display = 'none';
                e.stopPropagation(); // 문서 클릭 이벤트로 바로 닫히지 않게 방지
                return;
            }

            if (action && tableModule && tableModule[action]) {
                // 메뉴 클릭 시 에디터 포커스가 사라질 수 있으므로 위치 복구
                if (this.lastClickedIndex !== null) {
                    this.quill.setSelection(this.lastClickedIndex, 0);
                }
                tableModule[action](); // 예: tableModule.insertRowAbove() 실행
                this.autoSave();
            }
            contextMenu.style.display = 'none';
        });

        // --- 팔레트 이벤트 ---
        this.ui.colorPalette.addEventListener('click', (e) => {
            if (e.target.classList.contains('color-swatch')) {
                // 미리 지정된 색상 클릭
                const color = e.target.dataset.color;
                if (this.paletteContext === 'cell') {
                    this.applyCellColor(color);
                } else if (this.paletteContext === 'color') {
                    this.quill.focus();
                    this.quill.format('color', color);
                    this.autoSave();
                } else {
                    this.quill.focus();
                    this.quill.format('background', color);
                    this.autoSave();
                }
                this.ui.colorPalette.style.display = 'none';
            } else if (e.target.id === 'btn-custom-color') {
                // 커스텀 색상 버튼 클릭 -> 시스템 컬러 피커 열기
                this.ui.colorPicker.click();
                this.ui.colorPalette.style.display = 'none';
            }
        });

        // 시스템 컬러 피커 변경 시
        this.ui.colorPicker.addEventListener('input', (e) => {
            const color = e.target.value;
            if (this.paletteContext === 'cell') {
                this.applyCellColor(color);
            } else if (this.paletteContext === 'color') {
                this.quill.focus();
                this.quill.format('color', color);
                this.autoSave();
            } else {
                this.quill.focus();
                this.quill.format('background', color);
                this.autoSave();
            }
        });

        // 다른 곳 클릭 시 메뉴 및 팔레트 닫기
        document.addEventListener('click', (e) => {
            if (!e.target.closest('#table-context-menu')) contextMenu.style.display = 'none';
            if (!e.target.closest('#color-palette') && !e.target.closest('.ql-highlight') && !e.target.closest('.ql-color')) {
                this.ui.colorPalette.style.display = 'none';
            }
        });

        // --- 표 및 셀 크기 조절 이벤트 ---
        this.quill.root.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.quill.root.addEventListener('mousedown', (e) => this.handleMouseDown(e));
        document.addEventListener('mousemove', (e) => this.handleResizeDrag(e));
        document.addEventListener('mouseup', () => this.handleMouseUp());

        // 창 닫기/새로고침 시 저장되지 않은 내용이 있으면 경고
        window.addEventListener('beforeunload', (e) => {
            if (this.hasUnsavedChanges) {
                e.preventDefault();
                e.returnValue = ''; // Chrome에서는 이 설정이 필요함
            }
        });

        // 휴지통 이벤트 연결
        this.ui.trashFolder.onclick = () => {
            this.activeFolderId = 'trash';
            if (this.tagAddon) { this.tagAddon.activeTag = null; this.tagAddon.renderSidebarTags(); }
            this.renderFolders(); this.renderNotes();
        };
        this.ui.trashFolder.ondragover = (e) => { e.preventDefault(); this.ui.trashFolder.classList.add('drag-over'); };
        this.ui.trashFolder.ondragleave = () => this.ui.trashFolder.classList.remove('drag-over');
        this.ui.trashFolder.ondrop = (e) => { this.ui.trashFolder.classList.remove('drag-over'); this.handleNoteDrop(e, 'trash'); };
    }

    // 팔레트 UI 업데이트 (배경색용/텍스트색용)
    updatePaletteUI(type) {
        const colors = this.paletteColors[type];
        const swatches = this.ui.colorPalette.querySelectorAll('.color-swatch');
        swatches.forEach((swatch, index) => {
            if (colors[index]) {
                swatch.style.backgroundColor = colors[index].color;
                swatch.dataset.color = colors[index].color;
                swatch.title = colors[index].title;
            }
        });
    }

    // 셀 배경색 적용 헬퍼 메서드
    applyCellColor(color) {
        if (this.lastClickedIndex !== null) {
            const [leaf] = this.quill.getLeaf(this.lastClickedIndex);
            if (leaf) {
                const element = leaf.domNode.nodeType === 3 ? leaf.domNode.parentElement : leaf.domNode;
                const cell = element.closest('td, th');
                if (cell) {
                    cell.style.backgroundColor = color;
                    this.autoSave();
                }
            }
        }
    }

    setupShortcuts() {
        window.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'n') { e.preventDefault(); this.createNote(); }
            if (e.ctrlKey && e.key === 'f') { e.preventDefault(); this.ui.searchInput.focus(); }
            if (e.key === 'Delete' && document.activeElement === document.body) this.deleteNote();
            if (e.ctrlKey && e.key === 's') { 
                e.preventDefault(); 
                this.autoSave(); 
            }
        });

        // 에디터 내 키보드 이벤트 (제안 박스 네비게이션)
        this.quill.root.addEventListener('keydown', (e) => {
            if (this.linkSuggestionState.active) {
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    this.moveSuggestionSelection(1);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    this.moveSuggestionSelection(-1);
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    this.selectSuggestion();
                } else if (e.key === 'Escape') {
                    this.hideNoteSuggestions();
                }
            }
        });
    }

    // --- 리사이즈 핸들러 메서드 ---
    handleMouseMove(e) {
        if (this.resizeState.isResizing) return;

        // 이전에 하이라이트된 요소가 있다면 초기화
        this.clearHighlight();

        const target = e.target;
        const table = target.closest('table');
        const cell = target.closest('td, th');
        
        this.quill.root.style.cursor = ''; // 커서 초기화

        if (!table) return;

        const tableRect = table.getBoundingClientRect();
        const x = e.clientX;
        const y = e.clientY;
        const TOLERANCE = 15; // 감지 범위 (픽셀) - 선택 영역 확대

        // 1. 표 전체 크기 조절 (우측 하단 모서리)
        if (Math.abs(tableRect.right - x) < TOLERANCE && Math.abs(tableRect.bottom - y) < TOLERANCE) {
            this.quill.root.style.cursor = 'nwse-resize';
            this.resizeState.type = 'table';
            this.resizeState.target = table;
            table.classList.add('resize-highlight-table'); // 표 전체 강조
            this.highlightedTarget = table;
            return;
        }

        if (!cell) return;

        const rect = cell.getBoundingClientRect(); // 타겟이 아닌 셀 자체의 좌표 사용

        // 2. 열(Column) 너비 조절 (셀 우측 경계)
        if (Math.abs(rect.right - x) < TOLERANCE) {
            this.quill.root.style.cursor = 'col-resize';
            this.resizeState.type = 'col';
            this.resizeState.target = cell;
            cell.classList.add('resize-highlight-col'); // 오른쪽 테두리 강조
            this.highlightedTarget = cell;
            return;
        }

        // 3. 행(Row) 높이 조절 (셀 하단 경계)
        if (Math.abs(rect.bottom - y) < TOLERANCE) {
            this.quill.root.style.cursor = 'row-resize';
            this.resizeState.type = 'row';
            this.resizeState.target = cell.parentElement; // TR 요소
            cell.classList.add('resize-highlight-row'); // 아래쪽 테두리 강조
            this.highlightedTarget = cell;
            return;
        }
        
        this.resizeState.type = null;
        this.resizeState.target = null;
    }

    // 하이라이트 제거 메서드
    clearHighlight() {
        if (this.highlightedTarget) {
            this.highlightedTarget.classList.remove('resize-highlight-col', 'resize-highlight-row', 'resize-highlight-table');
            this.highlightedTarget = null;
        }
    }

    handleMouseDown(e) {
        if (this.resizeState.type && this.resizeState.target) {
            this.resizeState.isResizing = true;
            this.resizeState.startX = e.clientX;
            this.resizeState.startY = e.clientY;
            
            const rect = this.resizeState.target.getBoundingClientRect();
            this.resizeState.startWidth = rect.width;
            this.resizeState.startHeight = rect.height;
            
            e.preventDefault(); // 드래그 중 텍스트 선택 방지
        }
    }

    handleResizeDrag(e) {
        if (!this.resizeState.isResizing) return;

        const dx = e.clientX - this.resizeState.startX;
        const dy = e.clientY - this.resizeState.startY;
        const target = this.resizeState.target;

        if (this.resizeState.type === 'col') {
            const newWidth = Math.max(30, this.resizeState.startWidth + dx); // 최소 너비 30px
            target.style.width = `${newWidth}px`;

            // table-layout: fixed 에서는 colgroup이나 첫 번째 행의 셀 너비가 중요함
            const table = target.closest('table');
            if (table) {
                const cellIndex = target.cellIndex;
                
                // 1. colgroup이 있으면 col 너비 조절
                const colgroup = table.querySelector('colgroup');
                if (colgroup && colgroup.children[cellIndex]) {
                    colgroup.children[cellIndex].style.width = `${newWidth}px`;
                }
                
                // 2. 첫 번째 행의 해당 셀 너비도 강제 조절 (확실한 적용을 위해)
                if (table.rows[0] && table.rows[0].cells[cellIndex]) {
                    table.rows[0].cells[cellIndex].style.width = `${newWidth}px`;
                }
            }
        }
        else if (this.resizeState.type === 'row') {
            target.style.height = `${Math.max(30, this.resizeState.startHeight + dy)}px`;
        }
        else if (this.resizeState.type === 'table') {
            target.style.width = `${Math.max(100, this.resizeState.startWidth + dx)}px`;
        }
    }

    handleMouseUp() {
        if (this.resizeState.isResizing) {
            this.resizeState.isResizing = false;
            this.resizeState.type = null;
            this.resizeState.target = null;
            this.quill.root.style.cursor = '';
            this.clearHighlight(); // 드래그 종료 시 하이라이트 제거
            this.autoSave(); // 변경 사항 저장
        }
    }

    async createFolder() {
        const name = prompt('새 폴더 이름을 입력하세요:');
        if (!name || name.trim() === "") return;
        const folder = { id: Date.now().toString(), name: name.trim() };
        this.folders.push(folder);
        await this.storage.saveItem('folders', folder);
        this.renderFolders();
    }

    renderFolders() {
        this.ui.folderList.innerHTML = '';
        this.ui.folderList.appendChild(this.createFolderElement('all', '📂 모든 메모'));
        this.folders.forEach(f => this.ui.folderList.appendChild(this.createFolderElement(f.id, `📁 ${f.name}`)));
        
        // 휴지통 활성화 상태 업데이트
        if (this.activeFolderId === 'trash') {
            this.ui.trashFolder.classList.add('active');
        } else {
            this.ui.trashFolder.classList.remove('active');
        }
    }

    createFolderElement(id, text) {
        const li = document.createElement('li');
        li.className = `folder-item ${this.activeFolderId === id ? 'active' : ''}`;
        li.textContent = text;
        li.onclick = () => {
            this.activeFolderId = id;
            if (this.tagAddon) { this.tagAddon.activeTag = null; this.tagAddon.renderSidebarTags(); }
            this.renderFolders(); this.renderNotes();
        };
        li.ondragover = (e) => { e.preventDefault(); if (id !== 'all') li.classList.add('drag-over'); };
        li.ondragleave = () => li.classList.remove('drag-over');
        li.ondrop = (e) => { li.classList.remove('drag-over'); this.handleNoteDrop(e, id); };
        return li;
    }

    renderNotes(query = '') {
        this.ui.noteList.innerHTML = '';
        let filtered = this.notes;

        // 휴지통 여부에 따른 1차 필터링
        if (this.activeFolderId === 'trash') filtered = filtered.filter(n => n.isDeleted);
        else filtered = filtered.filter(n => !n.isDeleted);

        if (this.tagAddon && this.tagAddon.activeTag) {
            filtered = filtered.filter(n => n.tags && n.tags.includes(this.tagAddon.activeTag));
        } else if (this.activeFolderId !== 'all' && this.activeFolderId !== 'trash') {
            filtered = filtered.filter(n => n.folderId === this.activeFolderId);
        }

        if (query) {
            const q = query.toLowerCase();
            const filterType = document.querySelector('input[name="search-filter"]:checked').value;

            filtered = filtered.filter(n => {
                const matchTitle = n.title.toLowerCase().includes(q);
                const matchTag = n.tags && n.tags.some(t => t.toLowerCase().includes(q));
                const matchContent = n.content.toLowerCase().includes(q);

                if (filterType === 'tag') return matchTag;
                if (filterType === 'content') return matchContent;
                return matchTitle || matchTag || matchContent; // 전체
            });
        }

        // 정렬: 고정된 메모 우선, 그 다음 수정 시간 순
        filtered.sort((a,b) => {
            if (a.isPinned !== b.isPinned) return b.isPinned - a.isPinned; // true(1) > false(0)
            return b.updatedAt - a.updatedAt;
        });

        filtered.forEach(n => {
            const li = document.createElement('li');
            li.className = `note-card ${this.activeNoteId === n.id ? 'active' : ''}`;
            li.draggable = true;
            li.ondragstart = (e) => e.dataTransfer.setData('noteId', n.id);
            li.onclick = () => this.loadNote(n.id);
            li.oncontextmenu = (e) => {
                e.preventDefault();
                this.loadNote(n.id); // 우클릭 시 해당 메모 선택
                this.showNoteContextMenu(e, n);
            };
            const dateStr = new Date(n.updatedAt).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric' });
            const tagsStr = n.tags && n.tags.length > 0 ? n.tags.map(t => '#' + t).join(' ') : '내용 없음';
            const pinMark = n.isPinned ? '<span class="pinned-icon">📌</span> ' : '';
            li.innerHTML = `<div class="note-title">${pinMark}${n.title}</div><div class="note-info-row"><span class="note-date">${dateStr}</span><span class="note-preview">${tagsStr}</span></div>`;
            this.ui.noteList.appendChild(li);
        });
    }

    async createNote() {
        const folderId = this.activeFolderId === 'all' ? null : this.activeFolderId;
        const note = { id: Date.now().toString(), title: '새 메모', content: '{"ops":[{"insert":"\\n"}]}', updatedAt: Date.now(), folderId, tags: [], isDeleted: false, isPinned: false };
        
        // 노트 생성 시 실제 폴더도 생성 (Storage 구현 필요)
        if (this.storage.createNoteFolder) {
            await this.storage.createNoteFolder(note.id, folderId, note.title);
        }

        this.notes.unshift(note);
        await this.storage.saveItem('notes', note);
        this.loadNote(note.id);
    }

    // --- 데일리 노트 기능 ---
    async openDailyNote() {
        const today = new Date();
        const title = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
        
        // 1. "Daily Notes" 폴더 찾기 또는 생성
        let dailyFolder = this.folders.find(f => f.name === 'Daily Notes');
        if (!dailyFolder) {
            dailyFolder = { id: Date.now().toString(), name: 'Daily Notes' };
            this.folders.push(dailyFolder);
            await this.storage.saveItem('folders', dailyFolder);
            this.renderFolders();
        }

        // 2. 오늘 날짜의 메모 찾기 (Daily Notes 폴더 내)
        let targetNote = this.notes.find(n => n.title === title && n.folderId === dailyFolder.id && !n.isDeleted);
        
        if (!targetNote) {
            // 없으면 생성
            const content = {
                ops: [
                    { insert: title },
                    { attributes: { header: 1 }, insert: '\n' },
                    { insert: '\n' }
                ]
            };

            targetNote = { 
                id: Date.now().toString(), 
                title: title, 
                content: JSON.stringify(content), 
                updatedAt: Date.now(), 
                folderId: dailyFolder.id, 
                tags: ['daily'], 
                isDeleted: false, 
                isPinned: false 
            };
            
            if (this.storage.createNoteFolder) {
                await this.storage.createNoteFolder(targetNote.id, targetNote.folderId, targetNote.title);
            }

            this.notes.unshift(targetNote);
            await this.storage.saveItem('notes', targetNote);
            
            if (this.tagAddon) {
                this.tagAddon.rebuildTagCache();
                this.tagAddon.renderSidebarTags();
            }
        }

        // 3. 해당 폴더로 이동 및 메모 열기
        this.activeFolderId = dailyFolder.id;
        this.renderFolders();
        this.renderNotes();
        this.loadNote(targetNote.id);
    }

    // --- 섹션 접기/펼치기 로직 ---
    toggleSection(index) {
        const [headerLine] = this.quill.getLine(index);
        if (!headerLine) return;
        
        const headerFormat = headerLine.formats().header;
        if (!headerFormat) return; // 헤더가 아니면 중단

        // 현재 상태 확인 및 반전
        const isCollapsed = headerLine.formats()['section-collapsed'] === 'true';
        const newCollapsedState = !isCollapsed;

        // 헤더에 상태 적용 (화살표 회전용)
        this.quill.formatLine(index, headerLine.length(), 'section-collapsed', newCollapsedState ? 'true' : false);

        // 하위 내용 토글 (다음 헤더 전까지)
        let currentIndex = index + headerLine.length();
        const length = this.quill.getLength();
        
        while (currentIndex < length) {
            const [line] = this.quill.getLine(currentIndex);
            if (!line) break;
            
            const lineFormats = line.formats();
            // 동일하거나 더 높은 레벨(숫자가 작음)의 헤더를 만나면 중단
            if (lineFormats.header && lineFormats.header <= headerFormat) break;

            // 내용 숨김/표시 적용
            this.quill.formatLine(currentIndex, line.length(), 'collapsed-content', newCollapsedState ? 'true' : false);
            currentIndex += line.length();
        }
    }

    async loadNote(id) {
        this.activeNoteId = id;
        const note = this.notes.find(n => n.id === id);
        if (note) {
            this.deselectImage();
            try { this.quill.setContents(JSON.parse(note.content)); } catch(e) { this.quill.setContents([]); }
            this.ui.titleInput.value = note.title;
            if (this.tagAddon) this.tagAddon.renderTags(note.tags || []);
            
            // 휴지통 상태에 따른 UI 변경
            if (note.isDeleted) {
                this.ui.btnRestoreNote.style.display = 'inline-block';
                this.ui.btnDeleteNote.textContent = '영구 삭제';
            } else {
                this.ui.btnRestoreNote.style.display = 'none';
                this.ui.btnDeleteNote.textContent = '삭제 (Del)';
            }
            this.renderNotes();
            this.renderBacklinks(id);
        }
    }

    async autoSave() {
        if (!this.activeNoteId) return;

        this.ui.saveStatus.textContent = '저장 중...';
        this.ui.saveStatus.style.color = '#FF9500';

        const note = this.notes.find(n => n.id === this.activeNoteId);
        if (note) {
            const oldTitle = note.title;
            note.content = JSON.stringify(this.quill.getContents());
            note.updatedAt = Date.now();
            note.title = this.quill.getText().split('\n')[0].trim() || '새 메모';
            this.ui.titleInput.value = note.title;

            // 제목이 변경되었으면 폴더 이름도 변경
            if (oldTitle !== note.title && this.storage.renameNoteFolder) {
                await this.storage.renameNoteFolder(note.id, note.title);
            }

            await this.storage.saveItem('notes', note);
            this.renderNotes(this.ui.searchInput.value);
            if (this.tagAddon) this.tagAddon.renderSidebarTags();
            this.hasUnsavedChanges = false;
            
            this.ui.saveStatus.textContent = '✓ 저장됨';
            this.ui.saveStatus.style.color = '#34C759';
            
            if (this.saveStatusTimeout) clearTimeout(this.saveStatusTimeout);
            this.saveStatusTimeout = setTimeout(() => { this.ui.saveStatus.textContent = ''; }, 2000);
        }
    }

    // --- 백링크 렌더링 ---
    renderBacklinks(noteId) {
        // 현재 노트 ID를 링크로 포함하고 있는 다른 노트 검색
        const backlinks = this.notes.filter(n => 
            n.id !== noteId && 
            !n.isDeleted && 
            n.content.includes(`http://local-note/${noteId}"`)
        );

        if (backlinks.length > 0) {
            this.ui.backlinksArea.style.display = 'block';
            this.ui.backlinksList.innerHTML = '';
            backlinks.forEach(note => {
                const li = document.createElement('li');
                li.className = 'backlink-item';
                li.innerHTML = `<span class="backlink-icon">🔗</span>${note.title}`;
                li.onclick = () => this.loadNote(note.id);
                this.ui.backlinksList.appendChild(li);
            });
        } else {
            this.ui.backlinksArea.style.display = 'none';
        }
    }

    async handleNoteDrop(e, targetFolderId) {
        e.preventDefault();
        const noteId = e.dataTransfer.getData('noteId');
        const note = this.notes.find(n => n.id === noteId);
        if (note) {
            // 카테고리 이동 시 실제 폴더 이동 (Storage 구현 필요)
            if (this.storage.moveNote) {
                await this.storage.moveNote(note.id, targetFolderId);
            }

            if (targetFolderId === 'trash') {
                // 드래그로 휴지통 이동
                note.isDeleted = true;
            } else {
                note.folderId = targetFolderId === 'all' ? null : targetFolderId;
                note.isDeleted = false; // 다른 폴더로 이동 시 복구 효과
            }
            await this.storage.saveItem('notes', note);
            if (this.tagAddon) { this.tagAddon.rebuildTagCache(); this.tagAddon.renderSidebarTags(); }
            this.renderNotes();
        }
    }

    async deleteNote() {
        if (!this.activeNoteId) return;
        const note = this.notes.find(n => n.id === this.activeNoteId);
        if (!note) return;

        if (note.isDeleted) {
            // 이미 휴지통에 있는 경우 -> 영구 삭제
            if (confirm('이 메모를 영구적으로 삭제하시겠습니까? 복구할 수 없습니다.')) {
                if (this.storage.deleteNoteFolder) {
                    await this.storage.deleteNoteFolder(this.activeNoteId);
                }
                await this.storage.deleteItem('notes', this.activeNoteId);
                this.notes = this.notes.filter(n => n.id !== this.activeNoteId);
                this.postDeleteAction();
            }
        } else {
            // 일반 메모 -> 휴지통으로 이동 (Soft Delete)
            if (confirm('메모를 휴지통으로 이동하시겠습니까?')) {
                if (this.storage.moveNote) {
                    await this.storage.moveNote(note.id, 'trash');
                }
                note.isDeleted = true;
                await this.storage.saveItem('notes', note);
                this.postDeleteAction();
            }
        }
    }

    // 삭제/이동 후 처리 공통 로직
    postDeleteAction() {
            if (this.tagAddon) {
                this.tagAddon.rebuildTagCache(); // 삭제된 노트의 태그 반영을 위해 캐시 갱신
                this.tagAddon.renderSidebarTags();
            }
            // 현재 리스트에서 다음 메모 로드 또는 새 메모 생성
            // renderNotes를 먼저 호출하여 현재 뷰(휴지통 or 일반)에 맞는 리스트 갱신
            this.renderNotes();
            
            // 화면에 보이는 첫 번째 메모 로드
            const visibleNotes = Array.from(this.ui.noteList.children);
            if (visibleNotes.length > 0) {
                // DOM 요소에 연결된 데이터가 없으므로 notes 배열에서 다시 찾음
                // renderNotes 로직과 동일하게 필터링하여 첫 번째 요소 찾기
                let filtered = this.notes;
                if (this.activeFolderId === 'trash') filtered = filtered.filter(n => n.isDeleted);
                else filtered = filtered.filter(n => !n.isDeleted);
                
                if (this.activeFolderId !== 'all' && this.activeFolderId !== 'trash') {
                    filtered = filtered.filter(n => n.folderId === this.activeFolderId);
                }
                filtered.sort((a,b) => b.updatedAt - a.updatedAt);

                if (filtered.length > 0) this.loadNote(filtered[0].id);
                else this.createNote();
            } else {
                this.createNote();
            }
    }

    async restoreNote() {
        if (!this.activeNoteId) return;
        const note = this.notes.find(n => n.id === this.activeNoteId);
        if (note && note.isDeleted) {
            if (confirm('메모를 복구하시겠습니까?')) {
                if (this.storage.moveNote) {
                    await this.storage.moveNote(note.id, note.folderId || 'all');
                }
                note.isDeleted = false;
                await this.storage.saveItem('notes', note);
                if (this.tagAddon) {
                    this.tagAddon.rebuildTagCache();
                    this.tagAddon.renderSidebarTags();
                }
                // 복구 후 목록 갱신 및 첫 번째 메모 로드
                this.renderNotes();
                const filtered = this.notes.filter(n => n.isDeleted).sort((a,b) => b.updatedAt - a.updatedAt);
                if (filtered.length > 0) this.loadNote(filtered[0].id);
                else {
                    // 휴지통이 비었으면 전체 메모로 이동
                    this.activeFolderId = 'all';
                    this.renderFolders();
                    this.renderNotes();
                    if (this.notes.length > 0) this.loadNote(this.notes[0].id);
                }
            }
        }
    }

    // --- 컨텍스트 메뉴 관련 메서드 ---
    createNoteContextMenu() {
        this.noteContextMenu = document.createElement('div');
        this.noteContextMenu.className = 'context-menu';
        this.noteContextMenu.style.display = 'none';
        document.body.appendChild(this.noteContextMenu);

        // 외부 클릭 시 메뉴 닫기
        document.addEventListener('click', (e) => {
            if (!this.noteContextMenu.contains(e.target)) {
                this.noteContextMenu.style.display = 'none';
            }
        });
        
        // 메뉴 항목 클릭 핸들러
        this.noteContextMenu.addEventListener('click', (e) => {
            const action = e.target.dataset.action;
            if (!action) return;
            
            const noteId = this.contextMenuTargetNoteId;
            if (!noteId) return;

            if (action === 'delete') {
                this.deleteNote();
            } else if (action === 'restore') {
                this.restoreNote();
            } else if (action === 'togglePin') {
                this.togglePin(noteId);
            } else if (action === 'move') {
                const folderId = e.target.dataset.folderId;
                if (folderId) this.moveNoteToFolder(noteId, folderId);
            }
            this.noteContextMenu.style.display = 'none';
        });
    }

    showNoteContextMenu(e, note) {
        this.contextMenuTargetNoteId = note.id;
        this.noteContextMenu.innerHTML = '';

        if (note.isDeleted) {
            // 휴지통 상태일 때 메뉴
            this.noteContextMenu.innerHTML = `
                <div class="context-menu-item" data-action="restore">♻️ 복구</div>
                <div class="context-menu-separator"></div>
                <div class="context-menu-item" data-action="delete" style="color:red;">🗑️ 영구 삭제</div>
            `;
        } else {
            // 일반 상태일 때 메뉴 (이동할 폴더 목록 생성)
            let folderItems = '';
            this.folders.forEach(f => {
                if (f.id !== note.folderId) {
                    folderItems += `<div class="context-menu-item" data-action="move" data-folder-id="${f.id}">📁 ${f.name}</div>`;
                }
            });
            
            if (note.folderId && note.folderId !== 'all') {
                 folderItems = `<div class="context-menu-item" data-action="move" data-folder-id="all">📂 분류 없음</div>` + folderItems;
            }

            const pinLabel = note.isPinned ? '🚫 고정 해제' : '📌 상단 고정';
            this.noteContextMenu.innerHTML = `
                <div class="context-menu-item" data-action="togglePin">${pinLabel}</div>
                <div class="context-menu-separator"></div>
                <div class="context-menu-item" data-action="delete">🗑️ 삭제</div>
                <div class="context-menu-separator"></div>
                <div class="context-menu-header">이동할 폴더 선택</div>
                ${folderItems || '<div class="context-menu-header" style="font-weight:normal;">이동할 폴더 없음</div>'}
            `;
        }

        // 마우스 위치에 메뉴 표시
        const x = e.pageX;
        const y = e.pageY;
        this.noteContextMenu.style.left = `${x}px`;
        this.noteContextMenu.style.top = `${y}px`;
        this.noteContextMenu.style.display = 'block';
    }

    // --- 노트 링크 제안 (Note Linking) ---
    createNoteLinkSuggestionBox() {
        this.ui.suggestionBox = document.createElement('div');
        this.ui.suggestionBox.className = 'suggestion-box';
        document.body.appendChild(this.ui.suggestionBox);
    }

    handleNoteLinkInput() {
        const range = this.quill.getSelection();
        if (!range) return;

        // 커서 앞의 텍스트 확인
        const [line, offset] = this.quill.getLine(range.index);
        const textBefore = line.domNode.textContent.slice(0, offset);
        
        // '[[' 패턴 감지 (닫는 괄호나 줄바꿈이 없는 경우)
        const match = textBefore.match(/\[\[([^\]\n]*)$/);
        
        if (match) {
            const query = match[1];
            const startIndex = range.index - query.length - 2; // '[[' 길이 포함
            this.showNoteSuggestions(query, startIndex);
        } else {
            this.hideNoteSuggestions();
        }
    }

    showNoteSuggestions(query, startIndex) {
        this.linkSuggestionState.active = true;
        this.linkSuggestionState.startIndex = startIndex;
        this.linkSuggestionState.activeIndex = 0;

        // 검색어로 노트 필터링 (현재 노트 제외)
        const filtered = this.notes.filter(n => 
            n.id !== this.activeNoteId && 
            !n.isDeleted && 
            n.title.toLowerCase().includes(query.toLowerCase())
        );

        this.ui.suggestionBox.innerHTML = '';
        if (filtered.length === 0) {
            const div = document.createElement('div');
            div.className = 'suggestion-item';
            div.textContent = '검색 결과 없음';
            div.style.color = '#999';
            this.ui.suggestionBox.appendChild(div);
        } else {
            filtered.forEach((note, index) => {
                const div = document.createElement('div');
                div.className = `suggestion-item ${index === 0 ? 'active' : ''}`;
                div.textContent = note.title;
                div.dataset.noteId = note.id;
                div.onmousedown = (e) => {
                    e.preventDefault();
                    this.insertNoteLink(note);
                };
                this.ui.suggestionBox.appendChild(div);
            });
        }

        // 팝업 위치 설정
        const bounds = this.quill.getBounds(startIndex);
        const editorRect = document.getElementById('editor-container').getBoundingClientRect();
        
        this.ui.suggestionBox.style.display = 'block';
        this.ui.suggestionBox.style.left = `${editorRect.left + bounds.left}px`;
        this.ui.suggestionBox.style.top = `${editorRect.top + bounds.bottom + 5}px`;
    }

    hideNoteSuggestions() {
        this.linkSuggestionState.active = false;
        this.ui.suggestionBox.style.display = 'none';
    }

    moveSuggestionSelection(direction) {
        const items = this.ui.suggestionBox.querySelectorAll('.suggestion-item:not([style*="color: #999"])'); // 결과 없음 제외
        if (items.length === 0) return;

        items[this.linkSuggestionState.activeIndex].classList.remove('active');
        
        this.linkSuggestionState.activeIndex += direction;
        if (this.linkSuggestionState.activeIndex < 0) this.linkSuggestionState.activeIndex = items.length - 1;
        if (this.linkSuggestionState.activeIndex >= items.length) this.linkSuggestionState.activeIndex = 0;

        items[this.linkSuggestionState.activeIndex].classList.add('active');
        items[this.linkSuggestionState.activeIndex].scrollIntoView({ block: 'nearest' });
    }

    selectSuggestion() {
        const activeItem = this.ui.suggestionBox.querySelector('.suggestion-item.active');
        if (activeItem && activeItem.dataset.noteId) {
            const note = this.notes.find(n => n.id === activeItem.dataset.noteId);
            if (note) this.insertNoteLink(note);
        }
    }

    insertNoteLink(note) {
        const range = this.quill.getSelection();
        const startIndex = this.linkSuggestionState.startIndex;
        const length = range.index - startIndex;

        // '[[검색어' 부분을 노트 제목 링크로 교체
        this.quill.deleteText(startIndex, length);
        this.quill.insertText(startIndex, note.title, 'link', `http://local-note/${note.id}`, 'user');
        this.quill.insertText(startIndex + note.title.length, ' ', 'user'); // 뒤에 공백 추가
        this.quill.setSelection(startIndex + note.title.length + 1);
        
        this.hideNoteSuggestions();
    }

    async togglePin(noteId) {
        const note = this.notes.find(n => n.id === noteId);
        if (note) {
            note.isPinned = !note.isPinned;
            await this.storage.saveItem('notes', note);
            this.renderNotes(this.ui.searchInput.value);
        }
    }

    async moveNoteToFolder(noteId, targetFolderId) {
        const note = this.notes.find(n => n.id === noteId);
        if (!note) return;
        
        if (this.storage.moveNote) {
            await this.storage.moveNote(note.id, targetFolderId);
        }
        
        note.folderId = targetFolderId === 'all' ? null : targetFolderId;
        await this.storage.saveItem('notes', note);
        
        if (this.tagAddon) { 
            this.tagAddon.rebuildTagCache(); 
            this.tagAddon.renderSidebarTags(); 
        }
        this.postDeleteAction(); // 목록 갱신 및 다음 메모 로드
    }

    exportToPDF() {
        if (!this.activeNoteId) return;
        
        const element = this.quill.root; // 에디터 내용 전체
        const note = this.notes.find(n => n.id === this.activeNoteId);
        const filename = note ? `${note.title}.pdf` : 'memo.pdf';

        const opt = {
            margin:       15, // 여백 (mm)
            filename:     filename,
            image:        { type: 'jpeg', quality: 0.98 }, // 이미지 품질 설정
            html2canvas:  { scale: 2, useCORS: true, letterRendering: true }, // 고해상도 캡처
            jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().set(opt).from(element).toPdf().get('pdf').then((pdf) => {
            const totalPages = pdf.internal.getNumberOfPages();
            for (let i = 1; i <= totalPages; i++) {
                pdf.setPage(i);
                pdf.setFontSize(10);
                pdf.setTextColor(150);
                // 하단 중앙에 페이지 번호 표시 (예: 1 / 5)
                pdf.text(`${i} / ${totalPages}`, pdf.internal.pageSize.getWidth() / 2, pdf.internal.pageSize.getHeight() - 10, { align: 'center' });
            }
        }).save();
    }

    selectImage(img) { this.selectedImage = img; img.classList.add('selected-image'); const w = img.style.width ? parseInt(img.style.width) : 100; this.ui.slider.value = w; this.ui.percent.textContent = w + '%'; this.ui.tooltip.style.display = 'flex'; this.updateTooltipPos(); }
    deselectImage() { if (this.selectedImage) this.selectedImage.classList.remove('selected-image'); this.selectedImage = null; this.ui.tooltip.style.display = 'none'; }
    updateTooltipPos() {
        if (!this.selectedImage) return;
        const rect = this.selectedImage.getBoundingClientRect();
        const cont = document.getElementById('editor-container').getBoundingClientRect();
        this.ui.tooltip.style.top = (rect.top - cont.top) + 'px';
        this.ui.tooltip.style.left = (rect.left - cont.left + rect.width/2) + 'px';
    }
}

const app = new App();
window.onload = () => app.init();
window.app = app;