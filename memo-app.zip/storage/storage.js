export class Storage {
    constructor() {
        this.db = null;
        this.dbName = 'MemoAppDB';
        this.version = 4;

        // Node.js fs 모듈 초기화 (Electron 환경 가정)
        this.fs = null;
        this.path = null;
        this.baseDir = null;

        if (typeof window !== 'undefined' && window.require) {
            try {
                this.fs = window.require('fs');
                this.path = window.require('path');
                // 실행 위치에 'memo-data' 폴더 생성
                this.baseDir = this.path.join(process.cwd(), 'memo-data');
                if (!this.fs.existsSync(this.baseDir)) this.fs.mkdirSync(this.baseDir);
            } catch (e) {
                console.warn('File System access disabled or not in Electron environment.', e);
            }
        }
    }
    init() {
        return new Promise((res, rej) => {
            const req = indexedDB.open(this.dbName, this.version);
            req.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains('notes')) db.createObjectStore('notes', { keyPath: 'id' });
                if (!db.objectStoreNames.contains('folders')) db.createObjectStore('folders', { keyPath: 'id' });
            };
            req.onsuccess = (e) => { this.db = e.target.result; res(); };
            req.onerror = (e) => rej(e.target.error);
        });
    }
    async getItems(storeName) {
        const tx = this.db.transaction(storeName, 'readonly');
        return new Promise(res => { tx.objectStore(storeName).getAll().onsuccess = (e) => res(e.target.result); });
    }
    async saveItem(storeName, item) {
        const tx = this.db.transaction(storeName, 'readwrite');
        tx.objectStore(storeName).put(item);
    }
    async deleteItem(storeName, id) {
        const tx = this.db.transaction(storeName, 'readwrite');
        tx.objectStore(storeName).delete(id);
    }

    // --- 파일 시스템 관련 메서드 추가 ---

    // 폴더 이름 조회 헬퍼
    async getFolderName(folderId) {
        if (folderId === 'trash') return 'Trash';
        if (!folderId || folderId === 'all') return 'Uncategorized';
        return new Promise((resolve) => {
            const tx = this.db.transaction('folders', 'readonly');
            const req = tx.objectStore('folders').get(folderId);
            req.onsuccess = () => resolve(req.result ? req.result.name : 'Uncategorized');
            req.onerror = () => resolve('Uncategorized');
        });
    }

    // 파일명으로 쓸 수 없는 문자 제거
    sanitizeFileName(name) {
        return name.replace(/[\\/:*?"<>|]/g, '_');
    }

    // 노트 ID로 실제 파일 경로 찾기
    findNotePath(noteId) {
        if (!this.fs || !this.baseDir) return null;
        const categories = this.fs.readdirSync(this.baseDir);
        for (const cat of categories) {
            const catPath = this.path.join(this.baseDir, cat);
            // 디렉토리인 경우에만 탐색
            if (this.fs.statSync(catPath).isDirectory()) {
                // 폴더 이름이 "제목_ID" 형식이므로 ID로 끝나는 폴더를 찾음
                const items = this.fs.readdirSync(catPath);
                for (const item of items) {
                    if (item.endsWith(`_${noteId}`)) {
                        return this.path.join(catPath, item);
                    }
                }
            }
        }
        return null;
    }

    async createNoteFolder(noteId, folderId, title = '새 메모') {
        if (!this.fs) return;
        const categoryName = await this.getFolderName(folderId);
        const safeCatName = this.sanitizeFileName(categoryName);
        const catPath = this.path.join(this.baseDir, safeCatName);

        // 카테고리 폴더가 없으면 생성
        if (!this.fs.existsSync(catPath)) this.fs.mkdirSync(catPath);

        // 노트 폴더 생성 (제목_ID 형식)
        const folderName = `${this.sanitizeFileName(title)}_${noteId}`;
        const notePath = this.path.join(catPath, folderName);
        if (!this.fs.existsSync(notePath)) this.fs.mkdirSync(notePath);
    }

    async renameNoteFolder(noteId, newTitle) {
        if (!this.fs) return;
        const currentPath = this.findNotePath(noteId);
        if (!currentPath) return;

        const dirName = this.path.dirname(currentPath);
        const newFolderName = `${this.sanitizeFileName(newTitle)}_${noteId}`;
        const newPath = this.path.join(dirName, newFolderName);

        if (currentPath !== newPath) {
            try {
                this.fs.renameSync(currentPath, newPath);
            } catch (e) {
                console.error('Failed to rename folder:', e);
            }
        }
    }

    async deleteNoteFolder(noteId) {
        if (!this.fs) return;
        const notePath = this.findNotePath(noteId);
        if (notePath && this.fs.existsSync(notePath)) {
            try {
                this.fs.rmSync(notePath, { recursive: true, force: true });
            } catch (e) {
                console.error('Failed to delete folder:', e);
            }
        }
    }

    async saveNoteImage(noteId, file) {
        try {
            if (!this.fs) throw new Error('File System not available');
            
            const notePath = this.findNotePath(noteId);
            if (!notePath) {
                // 노트 폴더가 없으면 기본 폴더에 생성 시도
                // DB에서 제목을 가져오거나 기본값 사용
                await this.createNoteFolder(noteId, 'all', 'Untitled');
                return this.saveNoteImage(noteId, file);
            }

            const fileName = `${Date.now()}_${this.sanitizeFileName(file.name)}`;
            const filePath = this.path.join(notePath, fileName);

            // File 객체를 Buffer로 변환하여 저장
            const buffer = Buffer.from(await file.arrayBuffer());
            this.fs.writeFileSync(filePath, buffer);

            return `file://${filePath}`; // 에디터에서 표시할 수 있는 로컬 경로 반환
        } catch (e) {
            console.error('이미지 저장 실패:', e);
            alert('이미지 저장에 실패했습니다: ' + e.message);
            throw e;
        }
    }

    async moveNote(noteId, targetFolderId) {
        if (!this.fs) return;

        const currentPath = this.findNotePath(noteId);
        if (!currentPath) return; // 기존 경로를 못 찾으면 중단

        const newCategoryName = await this.getFolderName(targetFolderId);
        const safeCatName = this.sanitizeFileName(newCategoryName);
        const newCatPath = this.path.join(this.baseDir, safeCatName);
        
        if (!this.fs.existsSync(newCatPath)) this.fs.mkdirSync(newCatPath);

        const newPath = this.path.join(newCatPath, this.path.basename(currentPath));
        
        // 폴더 이동 (이름 변경)
        if (currentPath !== newPath) {
            try {
                this.fs.renameSync(currentPath, newPath);
            } catch (e) {
                console.error('Failed to move folder:', e);
            }
        }
    }
}